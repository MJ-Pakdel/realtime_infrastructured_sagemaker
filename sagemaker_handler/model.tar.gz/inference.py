import os
import json
import boto3
import joblib
import numpy as np
import io

# Environment variable must be set in Terraform/Lambda config
ENDPOINT_NAME = os.environ.get("SAGEMAKER_ENDPOINT")

# SageMaker Runtime client
runtime = boto3.client("sagemaker-runtime")

# These functions are required by the SageMaker scikit-learn container
def model_fn(model_dir):
    """Load model from the model_dir. This is the same model that was saved in
    the train.py example.
    """
    print(f"Loading model from: {model_dir}")
    model_path = os.path.join(model_dir, "model.joblib")
    model = joblib.load(model_path)
    return model

def input_fn(request_body, request_content_type):
    """Parse input data payload"""
    print(f"Received request with content type: {request_content_type}")

    # first, normalize to a str
    if isinstance(request_body, (bytes, bytearray)):
        body_str = request_body.decode("utf-8")
    else:
        body_str = request_body

    if request_content_type == "text/csv":
        # split on commas, turn into floats
        values = body_str.strip().split(",")
        return np.array([float(x) for x in values])

    elif request_content_type == "application/json":
        payload = json.loads(body_str)
        # support both {"instances":[[...]]} and {"features":[...]}
        if "instances" in payload:
            return np.array(payload["instances"])
        elif isinstance(payload, list):
            return np.array(payload)
        else:
            return np.array(payload.get("features", []))

    else:
        raise ValueError(f"Unsupported content type: {request_content_type}")
    
    
def predict_fn(input_data, model):
    """Predict using the model and input data
    """
    print(f"Predicting with input shape: {input_data.shape}")
    # Reshape the input if needed
    if len(input_data.shape) == 1:
        input_data = input_data.reshape(1, -1)
    return model.predict(input_data)

def output_fn(prediction, accept):
    """Format the prediction response
    """
    print(f"Returning prediction with accept type: {accept}")
    if accept == 'application/json':
        return json.dumps(prediction.tolist()), accept
    return str(prediction), accept

# Lambda handler function
def handler(event, context):
    # Parse the incoming request body
    body = json.loads(event.get("body", "{}"))
    features = body.get("features", [])

    # Placeholder transformation: add +1 to feature index 0
    if len(features) > 0:
        features[0] += 1

    # Convert to CSV bytes for SageMaker
    csv_payload = ",".join(map(str, features)).encode("utf-8")

    # Invoke SageMaker endpoint
    response = runtime.invoke_endpoint(
        EndpointName=ENDPOINT_NAME,
        ContentType="text/csv",
        Body=csv_payload
    )

    # Read the prediction result
    result = response["Body"].read().decode("utf-8")

    # Return JSON response
    return {
        "statusCode": 200,
        "body": json.dumps({
            "original_features": body.get("features", []),
            "transformed_features": features,
            "prediction": result
        })
    }